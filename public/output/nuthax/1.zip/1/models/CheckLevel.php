<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CheckLevel extends Model
{
    protected $guarded = ['id'];
}
