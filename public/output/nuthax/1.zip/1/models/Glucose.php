<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Glucose extends Model
{
    protected $guarded = ['id'];
}
