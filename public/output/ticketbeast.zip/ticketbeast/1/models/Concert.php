<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Concert extends Model
{
	protected $guarded = ['id'];
}
