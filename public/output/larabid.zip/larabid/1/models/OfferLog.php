<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OfferLog extends Model
{
	protected $guarded = ['id'];
}
