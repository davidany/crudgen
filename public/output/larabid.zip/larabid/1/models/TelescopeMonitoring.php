<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TelescopeMonitoring extends Model
{
	protected $guarded = ['id'];
}
