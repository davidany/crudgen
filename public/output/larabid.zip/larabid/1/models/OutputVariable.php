<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OutputVariable extends Model
{
	protected $guarded = ['id'];
}
