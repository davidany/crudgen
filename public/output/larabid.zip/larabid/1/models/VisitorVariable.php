<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VisitorVariable extends Model
{
	protected $guarded = ['id'];
}
