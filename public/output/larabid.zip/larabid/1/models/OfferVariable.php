<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OfferVariable extends Model
{
	protected $guarded = ['id'];
}
