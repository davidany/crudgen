<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TelescopeEntry extends Model
{
	protected $guarded = ['id'];
}
